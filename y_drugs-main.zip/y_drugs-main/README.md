Preview : https://www.youtube.com/watch?v=dk2oesRdC_s

Discord Aide : https://discord.gg/x7U22shmc3

Voici un esx_drugs dev par Moi. Pour ce script je suis parti d'un Job Vigneron !

- Système de Requirement de membre LSPD facile a config
- Argent Facile a config
- Système de Frezze qui permet 0 Bug
- Un Script Optimisé 0.01ms
- RageUI V2
- Système de Anti-Spam
