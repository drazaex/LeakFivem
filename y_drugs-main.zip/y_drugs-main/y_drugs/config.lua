Config = {}


-- Config LSPD
Config.CopsCoke = 1
Config.CopsOpium = 0
Config.Copsmeth = 0
Config.Copsweed = 0


-- Config Payement par drogue
Config.sellCoke = 200
Config.sellOpium = 0
Config.sellmeth = 300
Config.sellweed = 300
